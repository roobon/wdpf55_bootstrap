(function($) {
    "use strict"

    new dzSettings({
        direction: "rtl"
    });


})(jQuery);