(function($) {
    "use strict"

    new dzSettings({
        sidebarPosition: "fixed"
    });


})(jQuery);